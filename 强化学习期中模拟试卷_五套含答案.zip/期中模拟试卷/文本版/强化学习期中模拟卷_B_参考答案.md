# 强化学习期中模拟试卷 B｜参考答案与评分点

满分 100 分。等价推导可得同样分数；数值可保留分数形式或四位小数。

## 一、单项选择题（10 题，共 20 分）

| 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C | A | D | B | A | C | B | D | A | C |

1. C。$P^{\pi }(s,s')=\sum _{a}\pi (a|s)P(s'|s,a)$。

RL_4_MDP.pdf，第 40—41 页

2. A。策略评估对动作求策略加权平均。

RL_4_MDP.pdf，第 48—49 页

3. D。动作价值固定当前动作，后续遵循给定策略。

RL_4_MDP.pdf，第 42、46—52 页

4. B。在策略改进定理的条件下，逐状态选 $q^{\pi }$ 最大动作可得到不差的策略。

RL_5_DP.pdf，第 21、28—30 页

5. A。有限时域且奖励有界足够；只有有限状态不能排除无限循环。

RL_4_MDP.pdf，第 18—20 页

6. C。此时只有当前状态的资格迹为 1。

RL_6_Model-free Prediction.pdf，第 57—59 页

7. B。每个回合对该状态只计首次访问。

RL_6_Model-free Prediction.pdf，第 6—10 页

8. D。Q-learning 目标使用下一状态的最大动作值。

RL_9 Nature DQN 2015(1).pdf，第 7 页

9. A。$Q=V+A_{\mathrm{raw}}-\operatorname{mean}(A_{\mathrm{raw}})$，所以 $\operatorname{mean}(Q)=V$。

RL_10a DQN+(1).pdf，第 35—38 页

10. C。搜索以模型提供的模拟经验为基础。

RL_12 Integrated Learing & Planning(1).pdf，第 45—50 页


---

## 二、简答题（5 题，每题 5 分，共 25 分）

### 11. 写出状态价值的 Bellman 期望方程和最优性方程，并解释它们为何分别出现加权平均和最大值。（5 分）

【1 分】$v^{\pi }(s)=\sum _{a}\pi (a|s)\sum _{s',r}p(s',r|s,a)[r+\gamma v^{\pi }(s')]$。

【1 分】$v^{*}(s)=\max _{a}\sum _{s',r}p(s',r|s,a)[r+\gamma v^{*}(s')]$。

【1 分】期望方程评估已给定的 $\pi$，因此对动作按 $\pi$ 加权。

【1 分】最优性方程允许选择当前动作，因此对动作取最大值。

【1 分】两者对环境转移的随机性仍求期望；最大值不是挑选最好的随机结果。

课件依据：RL_4_MDP.pdf，第 48—56、64—68 页

### 12. 比较 policy iteration 与 value iteration 的基本步骤，并说明 generalized policy iteration 的含义。（5 分）

【1 分】Policy iteration 先评估当前策略。

【1 分】再对其 $q^{\pi }$ 贪婪改进，重复直到策略稳定。

【1 分】Value iteration 每轮直接做最优备份。

【1 分】可理解为截断评估与改进交替，最终提取贪婪策略。

【1 分】GPI 指价值评估与策略改进相互作用，二者不必每次都完全收敛。

课件依据：RL_5_DP.pdf，第 28—36、46—53 页

### 13. 从目标、偏差与方差、适用回合类型三个方面比较 MC 与 TD(0)。说明为什么不能简单说 TD 目标永远有偏。（5 分）

【1 分】MC 使用完整采样回报，TD 使用 $r+\gamma V(s')$。

【1 分】在给定策略和状态条件下，完整回报是 $v^{\pi }$ 的无偏样本。

【1 分】近似 V 的 TD 目标通常有偏；若 V 恰为真实 $v^{\pi }$，目标条件均值无偏。

【1 分】TD 通常有较低目标方差；MC 涉及更多未来随机事件。

【1 分】MC 需完成回合；TD 可从不完整序列或持续过程更新。

课件依据：RL_6_Model-free Prediction.pdf，第 26—28、39 页


---

## 二、简答题参考答案（续）

### 14. 写出 SARSA 和 Q-learning 更新式，并说明 on-policy/off-policy 的差别。（5 分）

【1 分】SARSA：$Q(s,a)\leftarrow Q(s,a)+\alpha [r+\gamma Q(s',a')-Q(s,a)]$。

【1 分】Q-learning：$Q(s,a)\leftarrow Q(s,a)+\alpha [r+\gamma \max _{b} Q(s',b)-Q(s,a)]$。

【1 分】SARSA 的 a' 由实际后续行为策略选择。

【1 分】SARSA 评估并改进当前行为策略，通常为 on-policy。

【1 分】Q-learning 目标使用贪婪后续动作，行为仍可探索，所以为 off-policy。

课件依据：RL_8 Value Function Approximation.pdf，第 34—38 页；RL_9 Nature DQN 2015(1).pdf，第 7 页

### 15. 区分 prioritized experience replay 与 prioritized sweeping：各自优先处理什么、是否利用模型前驱、为什么值得优先处理？（5 分）

【1 分】PER 对存储的经验转移设置采样优先级。

【1 分】常按 $\lvert\mathrm{TD\ error}\rvert+\varepsilon$ 构造优先级并随机采样。

【1 分】非均匀采样改变分布，可用重要性权重修正。

【1 分】Prioritized sweeping 借助模型和前驱关系，优先备份价值可能变化大的状态。

【1 分】两者都集中计算于可能较有信息的更新，但采样机制和模型依赖不同。

课件依据：RL_5_DP.pdf，第 56、58 页；RL_10a DQN+(1).pdf，第 14—27 页


---

## 三、MDP 计算题（3 题，共 25 分）

### 16. 联合奖励与条件奖励（8 分）

固定 (S,a) 的联合转移见表。T 终止，$\gamma =0.8$；后续价值估计 $V(Y)=5$、$V(T)=0$。

| 下一状态 | 奖励 | 联合概率 |
| --- | --- | --- |
| Y | $-2$ | 0.4 |
| Y | 2 | 0.1 |
| T | 4 | 0.5 |

（1）求 $P(Y|S,a)$、$P(T|S,a)$。（2 分）

参考答案与评分：$P(Y)=0.4+0.1=0.5$，$P(T)=0.5$。各 1 分。

（2）求 $r(S,a)$。（2 分）

参考答案与评分：$r=0.4\times (-2)+0.1\times 2+0.5\times 4=1.4$。公式与结果各 1 分。

（3）求 $\mathbb{E}[R_{t+1}|S_{t}=S,A_{t}=a,S_{t+1}=Y]$。（2 分）

参考答案与评分：$\dfrac{0.4\times (-2)+0.1\times 2}{0.4+0.1}=-1.2$。条件化分母与结果各 1 分。

（4）求动作 a 的一次期望备份。（2 分）

参考答案与评分：$q_{\mathrm{backup}}=1.4+0.8\times 0.5\times 5=3.4$。保留随机下一状态的概率权重。

课件依据：RL_3_Formulation.pdf，第 30—31 页；RL_4_MDP.pdf，第 50—52 页


---

## 三、MDP 计算题（3 题，共 25 分）（续）

### 17. 含自转移的策略评估（8 分）

给定策略诱导的 MRP，只列非终止状态 X、Y：$P^{\pi }=\begin{bmatrix}0.5 & 0.5 \\ 0.25 & 0\end{bmatrix}$，$r^{\pi }=(1,2)^{\mathsf T}$。Y 剩余的 0.75 概率流向 T。$\gamma =0.5$，$V(T)=0$。

（1）写出 $I-\gamma P^{\pi }$ 和线性方程 $(I-\gamma P^{\pi })v=r^{\pi }$。（2 分）

参考答案与评分：$I-\gamma P^{\pi }=\begin{bmatrix}0.75 & -0.25 \\ -0.125 & 1\end{bmatrix}$；即 $0.75v_{X}-0.25v_{Y}=1$，$-0.125v_{X}+v_{Y}=2$。矩阵与方程各 1 分。

（2）精确求 $v^{\pi }(X)$、$v^{\pi }(Y)$。（2 分）

参考答案与评分：$v_{X}=\dfrac{48}{23}\approx 2.0870$，$v_{Y}=\dfrac{52}{23}\approx 2.2609$。各 1 分。

（3）从 $V_{0}=(0,0)$ 做两轮同步策略评估，求 $V_{1}$、$V_{2}$。（2 分）

参考答案与评分：$V_{1}=(1,2)$；$V_{2}=(1+0.5\times (0.5+1),2+0.5\times 0.25\times 1)=(1.75,2.125)$。各轮 1 分。

（4）求第二轮后的实际无穷范数误差 $\lVert v^{\pi }-V_{2}\rVert_{\infty}$。（2 分）

参考答案与评分：X 误差为 $\dfrac{48}{23}-\dfrac{7}{4}=\dfrac{31}{92}$；Y 误差为 $\dfrac{52}{23}-\dfrac{17}{8}=\dfrac{25}{184}$。最大值为 $\dfrac{31}{92}\approx 0.3370$。误差比较与最终值各 1 分。

课件依据：RL_4_MDP.pdf，第 56 页；RL_5_DP.pdf，第 10—12、65 页


---

## 三、MDP 计算题（3 题，共 25 分）（续）

### 18. 策略迭代与并列改进（9 分）

确定性 MDP 见表，T 终止，$\gamma =0.5$。初始策略 $\pi _{0}$ 在 X、Y 都选择 quit。改进时若原动作也达到最大值，则保留原动作。

| 状态 | 动作 | 奖励 | 下一状态 |
| --- | --- | --- | --- |
| X | quit | 2 | T |
| X | go | 0 | Y |
| Y | quit | 1 | T |
| Y | back | 3 | X |

（1）求 $v^{\pi _{0}}(X)$、$v^{\pi _{0}}(Y)$。（2 分）

参考答案与评分：$v^{\pi _{0}}=(2,1)$。各状态 1 分。

（2）计算 $q^{\pi _{0}}$ 的四个动作值并给出 $\pi _{1}$。（2 分）

参考答案与评分：X：$\mathrm{quit}=2$，$\mathrm{go}=0.5$；Y：$\mathrm{quit}=1$，$\mathrm{back}=3+0.5\times 2=4$。动作值 1 分；$\pi _{1}=(\mathrm{quit},\mathrm{back})$，1 分。

（3）精确评估 $\pi _{1}$。（2 分）

参考答案与评分：$v_{X}=2$，$v_{Y}=3+0.5\times 2=4$。各 1 分。

（4）再做一次改进，判断是否已最优，并写出每个状态的全部最优动作。（3 分）

参考答案与评分：X 的 $\mathrm{quit}=2$、$\mathrm{go}=0.5\times 4=2$ 并列；Y 的 $\mathrm{back}=4>\mathrm{quit}=1$，1 分。按保留规则 $\pi _{2}=\pi _{1}$，已满足 Bellman 最优性，1 分。全部最优动作：X 为 {quit,go}，Y 为 {back}，1 分。

课件依据：RL_5_DP.pdf，第 21、28—36 页


---

## 四、学习算法计算题（2 题，共 20 分）

### 19. SARSA、Q-learning 与终止目标（10 分）

一次非终止样本为 $(s,a,r=-1,s')$，实际下一动作 $a'=\mathrm{left}$。$\gamma =0.9$、$\alpha =0.5$；初始 $Q(s,a)=2$、$Q(s',\mathrm{left})=1$、$Q(s',\mathrm{right})=5$。不同算法都从这些初值独立计算。标准 $\varepsilon$-greedy 从全部动作均匀探索。

（1）求 SARSA 的目标 y。（2 分）

参考答案与评分：$y=-1+0.9\times 1=-0.1$。公式与值各 1 分。

（2）求该次 SARSA 更新后的 $Q(s,a)$。（2 分）

参考答案与评分：$2+0.5\times (-0.1-2)=0.95$。更新式与值各 1 分。

（3）求 Q-learning 的目标与更新后 $Q(s,a)$。（2 分）

参考答案与评分：$y=-1+0.9\times 5=3.5$；$Q_{\mathrm{new}}=2+0.5\times (3.5-2)=2.75$。各 1 分。

（4）在 s' 取 $\varepsilon =0.2$ 时，left 和 right 各有多大选择概率？（2 分）

参考答案与评分：$\mathrm{left}=\dfrac{\varepsilon }{2}=0.1$；$\mathrm{right}=1-\varepsilon +\dfrac{\varepsilon }{2}=0.9$。各 1 分。

（5）另有一个独立的终止样本 $(s,a,r=-2,T)$，同样从 $Q(s,a)=2$ 开始。SARSA 与 Q-learning 各更新成多少？（2 分）

参考答案与评分：终止目标均为 $-2$，下一价值为 0。两者 $Q_{\mathrm{new}}=2+0.5\times (-2-2)=0$。终止处理与结果各 1 分。

课件依据：RL_8 Value Function Approximation.pdf，第 38 页；RL_9 Nature DQN 2015(1).pdf，第 7 页


---

## 四、学习算法计算题（2 题，共 20 分）（续）

### 20. 有限经验的 batch MC 与 batch TD（10 分）

$\gamma =1$，T 终止，只有以下 5 个回合：①$A \xrightarrow{0} B \xrightarrow{1} T$；②$A \xrightarrow{0} B \xrightarrow{0} T$；③$B \xrightarrow{1} T$；④$B \xrightarrow{1} T$；⑤$B \xrightarrow{0} T$。MC 使用每次访问的回报均值；batch TD 指重复利用该固定批次、求经验 Markov 模型对应的 TD 固定点。

（1）求从 A 开始的两个回合中 A 的回报。（2 分）

参考答案与评分：回合①的 $G_{A}=1$，回合②的 $G_{A}=0$。各 1 分。

（2）求 batch MC 的 $V(A)$、$V(B)$。（2 分）

参考答案与评分：$V_{\mathrm{MC}}(A)=\dfrac{1+0}{2}=0.5$；$V_{\mathrm{MC}}(B)=\dfrac{1+0+1+1+0}{5}=0.6$。各 1 分。

（3）按频数和奖励均值估计 $\hat{P}(B|A)$、$\hat{r}(A)$、$\hat{P}(T|B)$、$\hat{r}(B)$。（2 分）

参考答案与评分：$\hat{P}(B|A)=1$、$\hat{r}(A)=0$；$\hat{P}(T|B)=1$、$\hat{r}(B)=\dfrac{3}{5}=0.6$。A 模型与 B 模型各 1 分。

（4）求 batch TD 的 $V(A)$、$V(B)$。（2 分）

参考答案与评分：$V_{\mathrm{TD}}(B)=0.6$；$V_{\mathrm{TD}}(A)=0+1\times V_{\mathrm{TD}}(B)=0.6$。各 1 分。

（5）为什么两种方法对 A 的估计不同？（2 分）

参考答案与评分：MC 仅拟合从 A 出发实际观察到的回报，1 分。TD 利用 Markov 假设把所有 B 的观测共享到 A 的后续价值，所以使用 B 的整体均值，1 分。

课件依据：RL_6_Model-free Prediction.pdf，第 32—39 页


---

## 五、最优策略计算题（1 题，共 10 分）

### 21. 投资、兑现与折扣阈值（10 分）

状态 S、W、T，T 终止。S 的 safe 动作奖励 2 后到 T；invest 奖励 $-1$ 后到 W。W 的 cash 奖励 6 后到 T；retry 奖励 0，之后以各 0.5 概率到 W、T。先取 $\gamma =0.75$。

（1）写出 W 的最优性方程并求 $v^{*}(W)$。（2 分）

参考答案与评分：$v_{W}=\max \left\{6,0.75\times 0.5v_{W}\right\}=\max \left\{6,0.375v_{W}\right\}$，故 $v_{W}=6$，cash 最优。方程与解各 1 分。

（2）求 S 的两个 $q^{*}$ 值。（2 分）

参考答案与评分：$q^{*}(S,\mathrm{safe})=2$；$q^{*}(S,\mathrm{invest})=-1+0.75\times 6=3.5$。各 1 分。

（3）写出两状态的最优策略和最优价值，并核对未选动作。（3 分）

参考答案与评分：$\pi ^{*}(S)=\mathrm{invest}$、$\pi ^{*}(W)=\mathrm{cash}$，1 分；$v^{*}(S)=3.5$、$v^{*}(W)=6$，1 分；W 的 retry 值为 $0.375\times 6=2.25<6$，S 的 $\mathrm{safe}=2<3.5$，1 分。

（4）让 $\gamma$ 在 [0,1) 内变化，求 S 的最优动作切换阈值及阈值处的全部最优动作。（3 分）

参考答案与评分：W 的 cash 始终最优，$v_{W}=6$，1 分。S 比较 2 与 $-1+6\gamma$，阈值 $\gamma =0.5$；小于时 safe、大于时 invest，1 分。等于时二者并列，1 分。

课件依据：RL_4_MDP.pdf，第 57—68 页
